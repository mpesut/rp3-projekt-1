﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    internal class DBfunctions
    {
        protected SqlConnection GetConnection()
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source = DESKTOP-6QIQN40; database = myHotel; integrated security = True";
                return con;
            }
            catch
            {
                MessageBox.Show("Can't connect to database myHotel!");
                return null;
            }
        }

        public DataSet getData(string query)
        {
            SqlConnection conn = GetConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = query;

            try
            {
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
            catch(Exception)
            {
                MessageBox.Show("Can't retrieve data from DataBase!");
                return null;
            }

        }

        public void setData(string query, string message)
        {
            SqlConnection con = GetConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            try
            {
                con.Open();
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch(Exception) 
            {
                MessageBox.Show("Can't add to DataBase!");
                return;
            }            

            MessageBox.Show("'" + message + "'", "Success", MessageBoxButtons.OK);
        }

        public SqlDataReader getCombo(string query)
        {
            SqlConnection con = GetConnection();
            SqlCommand cmd = new SqlCommand();
            try
            {
                cmd.Connection = con;
                con.Open();
                cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                return dr;
            }
            catch(Exception)
            {
                MessageBox.Show("Failed retrieving data from database! (comboBox)");
                return null;
            }
        }
    }
}
