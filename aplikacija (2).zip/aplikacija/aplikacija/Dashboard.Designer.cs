﻿namespace aplikacija
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.movingPanel = new System.Windows.Forms.Panel();
            this.invoiceBtn = new System.Windows.Forms.Button();
            this.roomBtn = new System.Windows.Forms.Button();
            this.customerBtn = new System.Windows.Forms.Button();
            this.employeeBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.invoices1 = new aplikacija.Invoices();
            this.newCustomer1 = new aplikacija.newCustomer();
            this.uC_AddRoom1 = new aplikacija.User_Control.UC_AddRoom();
            this.customers2 = new aplikacija.customers();
            this.customers1 = new aplikacija.customers();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.movingPanel);
            this.panel1.Controls.Add(this.invoiceBtn);
            this.panel1.Controls.Add(this.roomBtn);
            this.panel1.Controls.Add(this.customerBtn);
            this.panel1.Controls.Add(this.employeeBtn);
            this.panel1.Location = new System.Drawing.Point(276, 12);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1298, 313);
            this.panel1.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(1184, 2);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(69, 60);
            this.button2.TabIndex = 4;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // movingPanel
            // 
            this.movingPanel.BackColor = System.Drawing.Color.MistyRose;
            this.movingPanel.Location = new System.Drawing.Point(3, 172);
            this.movingPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.movingPanel.Name = "movingPanel";
            this.movingPanel.Size = new System.Drawing.Size(172, 10);
            this.movingPanel.TabIndex = 0;
            // 
            // invoiceBtn
            // 
            this.invoiceBtn.BackColor = System.Drawing.Color.MistyRose;
            this.invoiceBtn.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invoiceBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.invoiceBtn.Location = new System.Drawing.Point(578, 41);
            this.invoiceBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.invoiceBtn.Name = "invoiceBtn";
            this.invoiceBtn.Size = new System.Drawing.Size(172, 112);
            this.invoiceBtn.TabIndex = 3;
            this.invoiceBtn.Text = "Invoice";
            this.invoiceBtn.UseVisualStyleBackColor = false;
            this.invoiceBtn.Click += new System.EventHandler(this.invoiceBtn_Click);
            // 
            // roomBtn
            // 
            this.roomBtn.BackColor = System.Drawing.Color.MistyRose;
            this.roomBtn.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomBtn.Location = new System.Drawing.Point(3, 41);
            this.roomBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.roomBtn.Name = "roomBtn";
            this.roomBtn.Size = new System.Drawing.Size(172, 112);
            this.roomBtn.TabIndex = 0;
            this.roomBtn.Text = "Room details";
            this.roomBtn.UseVisualStyleBackColor = false;
            this.roomBtn.Click += new System.EventHandler(this.roomBtn_Click);
            // 
            // customerBtn
            // 
            this.customerBtn.BackColor = System.Drawing.Color.MistyRose;
            this.customerBtn.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerBtn.Location = new System.Drawing.Point(195, 41);
            this.customerBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.customerBtn.Name = "customerBtn";
            this.customerBtn.Size = new System.Drawing.Size(172, 112);
            this.customerBtn.TabIndex = 1;
            this.customerBtn.Text = "Customer registration";
            this.customerBtn.UseVisualStyleBackColor = false;
            this.customerBtn.Click += new System.EventHandler(this.customerBtn_Click);
            // 
            // employeeBtn
            // 
            this.employeeBtn.BackColor = System.Drawing.Color.MistyRose;
            this.employeeBtn.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeBtn.Location = new System.Drawing.Point(388, 41);
            this.employeeBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.employeeBtn.Name = "employeeBtn";
            this.employeeBtn.Size = new System.Drawing.Size(172, 112);
            this.employeeBtn.TabIndex = 2;
            this.employeeBtn.Text = "Customer details";
            this.employeeBtn.UseVisualStyleBackColor = false;
            this.employeeBtn.Click += new System.EventHandler(this.employeeBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(36, 16);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 195);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.invoices1);
            this.panel2.Controls.Add(this.newCustomer1);
            this.panel2.Controls.Add(this.uC_AddRoom1);
            this.panel2.Controls.Add(this.customers2);
            this.panel2.Location = new System.Drawing.Point(36, 241);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1483, 630);
            this.panel2.TabIndex = 4;
            // 
            // invoices1
            // 
            this.invoices1.BackColor = System.Drawing.SystemColors.Window;
            this.invoices1.Location = new System.Drawing.Point(0, 0);
            this.invoices1.Name = "invoices1";
            this.invoices1.Size = new System.Drawing.Size(1492, 630);
            this.invoices1.TabIndex = 4;
            this.invoices1.Visible = false;
            // 
            // newCustomer1
            // 
            this.newCustomer1.BackColor = System.Drawing.Color.MistyRose;
            this.newCustomer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.newCustomer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.newCustomer1.Location = new System.Drawing.Point(0, 0);
            this.newCustomer1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.newCustomer1.Name = "newCustomer1";
            this.newCustomer1.Size = new System.Drawing.Size(1483, 630);
            this.newCustomer1.TabIndex = 3;
            this.newCustomer1.Visible = false;
            // 
            // uC_AddRoom1
            // 
            this.uC_AddRoom1.BackColor = System.Drawing.Color.White;
            this.uC_AddRoom1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uC_AddRoom1.Location = new System.Drawing.Point(0, 0);
            this.uC_AddRoom1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.uC_AddRoom1.Name = "uC_AddRoom1";
            this.uC_AddRoom1.Size = new System.Drawing.Size(1483, 630);
            this.uC_AddRoom1.TabIndex = 0;
            this.uC_AddRoom1.Visible = false;
            // 
            // customers2
            // 
            this.customers2.BackColor = System.Drawing.Color.White;
            this.customers2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customers2.Location = new System.Drawing.Point(0, 0);
            this.customers2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.customers2.Name = "customers2";
            this.customers2.Size = new System.Drawing.Size(1483, 630);
            this.customers2.TabIndex = 2;
            this.customers2.Visible = false;
            // 
            // customers1
            // 
            this.customers1.BackColor = System.Drawing.Color.White;
            this.customers1.Location = new System.Drawing.Point(1703, 203);
            this.customers1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.customers1.Name = "customers1";
            this.customers1.Size = new System.Drawing.Size(1500, 663);
            this.customers1.TabIndex = 3;
            this.customers1.Visible = false;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(1582, 1003);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.customers1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dashboard";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button invoiceBtn;
        private System.Windows.Forms.Button roomBtn;
        private System.Windows.Forms.Button customerBtn;
        private System.Windows.Forms.Button employeeBtn;
        private System.Windows.Forms.Panel movingPanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
        private customers customers1;
        private System.Windows.Forms.Panel panel2;
        private User_Control.UC_AddRoom uC_AddRoom1;
        private customers customers2;
        private newCustomer newCustomer1;
        private Invoices invoices1;
    }
}