﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            uC_AddRoom1.Visible = true;
            uC_AddRoom1.dodanaSoba += customers1.customers_Load;
            uC_AddRoom1.dodanaSoba += customers2.customers_Load;
            newCustomer1.guestAdded += customers1.customers_Load;
            newCustomer1.guestAdded += customers2.customers_Load;
            newCustomer1.guestAdded += uC_AddRoom1.UC_AddRoom_Load;
            newCustomer1.guestAdded += invoices1.Invoices_Load;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void employeeBtn_Click(object sender, EventArgs e)
        {
            movingPanel.Left = employeeBtn.Left;
            uC_AddRoom1.Visible = false;
            newCustomer1.Visible = false;
            invoices1.Visible = false;
            customers1.Visible = false;
            customers2.Visible = true;
        }

        private void invoiceBtn_Click(object sender, EventArgs e)
        {
            movingPanel.Left = invoiceBtn.Left;
            customers2.Visible = false;
            customers1.Visible = false;
            uC_AddRoom1.Visible = false;
            newCustomer1.Visible = false;
            invoices1.Visible = true;
            panel2.Controls.Add(invoices1);
        }

        private void customerBtn_Click(object sender, EventArgs e)
        {
            movingPanel.Left = customerBtn.Left;
            uC_AddRoom1.Visible = false;
            customers2.Visible = false;
            customers1.Visible = false;
            invoices1.Visible = false;
            newCustomer1.Visible = true;
            panel2.Controls.Add(newCustomer1);
        }

        private void roomBtn_Click(object sender, EventArgs e)
        {
            movingPanel.Left = roomBtn.Left;
            uC_AddRoom1.Visible = true;
            newCustomer1.Visible = false;
            customers2.Visible = false;
            customers1.Visible = false;
            invoices1.Visible = false;
            panel2.Controls.Add(uC_AddRoom1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            //btnAddRoom.PerformCLick();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
