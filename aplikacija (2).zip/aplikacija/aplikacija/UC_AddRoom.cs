﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija.User_Control
{
    public partial class UC_AddRoom : UserControl
    {
        DBfunctions fn = new DBfunctions();
        string query;
        public event EventHandler<EventArgs> dodanaSoba;
        public UC_AddRoom()
        {
            InitializeComponent();
            capacity();
            bestBuy();
        }

        public void UC_AddRoom_Load(object sender, EventArgs e)
        {
            query = "select * from Rooms";
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns[0].ReadOnly = true;
            capacity();
            bestBuy();
        }

        private void btnAddRoom_Click(object sender, EventArgs e)
        {
            if(txtRoomNo.Text != "" && txtRoomNo.Text != "" && txtRoomType.Text != "" && txtBeds.Text != "")
            {
                string number = txtRoomNo.Text;
                string typeR = txtRoomType.Text;
                string beds = txtBeds.Text;
                Int64 price = Int64.Parse(txtPrice.Text);

                query = "insert into Rooms (roomNo, roomType, beds, price) values ('" + number + "','" + typeR + "','" + beds + "'," + price + ")";
                try
                {
                    fn.setData(query, "Room added!");
                }
                catch
                {
                    MessageBox.Show("Već postoji soba sa unesenim brojem. Unesite drugi broj.", "Greška");
                }

                UC_AddRoom_Load(this, null);
                dodanaSoba(this, null);
                ClearAll();
                capacity();
            }
            else
            {
                MessageBox.Show("Fill all the fields!", "Warning !!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ClearAll()
        {
            txtRoomNo.Clear();
            txtPrice.Clear();
            txtBeds.SelectedIndex = -1;
            txtRoomType.SelectedIndex = -1;
        }

        private void UC_AddRoom_Leave(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void buttonShowFree_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = fn.getData("SELECT * FROM Rooms WHERE booked is NULL").Tables[0];
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = fn.getData("SELECT * FROM Rooms").Tables[0];
        }

        private void buttonFilterRooms_Click(object sender, EventArgs e)
        {
            string filterNumber = txtRoomNo.Text;
            string filterType = txtRoomType.SelectedValue.ToString();
            string filterBeds = txtBeds.Text;
            string filterPrice = txtPrice.Text;
            string query;

            //NIJE GOTOVO
            /*if (filterNumber.Length > 0)
            {
                query = "SELECT * FROM Rooms WHERE roomNo = '" + filterNumber + "'";
                data
            }*/
        }

        private void capacity()
        {
            DataSet all = fn.getData("SELECT * from Rooms");
            DataSet free = fn.getData("SELECT * from Rooms where booked is null");
            int c = (int)(((double)free.Tables[0].Rows.Count / (double)all.Tables[0].Rows.Count) * 100);

            DataSet allClassic = fn.getData("SELECT * from Rooms WHERE roomType = 'Classic'");
            DataSet freeClassic = fn.getData("SELECT * from Rooms where booked is null and roomType = 'Classic'");
            int cclassic = (int)(((double)freeClassic.Tables[0].Rows.Count / (double)allClassic.Tables[0].Rows.Count) * 100);

            DataSet allApartman = fn.getData("SELECT * from Rooms WHERE roomType = 'Apartman'");
            DataSet freeApartman = fn.getData("SELECT * from Rooms where booked is null and roomType = 'Apartman'");
            int capartman = (int)(((double)freeApartman.Tables[0].Rows.Count / (double)allApartman.Tables[0].Rows.Count) * 100);

            DataSet allPremium = fn.getData("SELECT * from Rooms WHERE roomType = 'Premium'");
            DataSet freePremium = fn.getData("SELECT * from Rooms where booked is null and roomType = 'Premium'");
            int cpremium = (int)(((double)freePremium.Tables[0].Rows.Count / (double)allPremium.Tables[0].Rows.Count) * 100);

            DataSet allSingle = fn.getData("SELECT * from Rooms WHERE beds = 'Single'");
            DataSet freeSingle = fn.getData("SELECT * from Rooms where booked is null and beds = 'Single'");
            int cSingle = (int)(((double)freeSingle.Tables[0].Rows.Count / (double)allSingle.Tables[0].Rows.Count) * 100);

            DataSet allDouble = fn.getData("SELECT * from Rooms WHERE beds = 'Double'");
            DataSet freeDouble = fn.getData("SELECT * from Rooms where booked is null and beds = 'Double'");
            int cDouble = (int)(((double)freeDouble.Tables[0].Rows.Count / (double)allDouble.Tables[0].Rows.Count) * 100);

            DataSet allTriple = fn.getData("SELECT * from Rooms WHERE beds = 'Triple'");
            DataSet freeTriple = fn.getData("SELECT * from Rooms where booked is null and beds = 'Triple'");
            int cTriple = (int)(((double)freeTriple.Tables[0].Rows.Count / (double)allTriple.Tables[0].Rows.Count) * 100);

            labelCapacity.Text = "FREE CAPACITY: " + c + "% " + "| Classic: " + cclassic + "% | Apartman: " + capartman + "% | Premium: " + cpremium + "%"
                 + " | Single: " + cSingle + "% | Double: " + cDouble + "% | Triple:" + cTriple + "%";
        }

        private int roomCapacity(string beds)
        {
            switch (beds)
            {
                case "Single": return 1;
                case "Double": return 2;
                case "Triple": return 3;
            }
            return 0;
        }

        private void bestBuy()
        {
            DataSet table = fn.getData("SELECT roomID, price, beds FROM Rooms");
            DataTable table2 = table.Tables[0];
            double min = (long)table2.Rows[0]["price"];
            int id = (int)table2.Rows[0]["roomID"];

            for(int i = 0; i < table2.Rows.Count; i++)
            {
                DataRow row = table2.Rows[i];
                int roomid = (int)row["roomID"];
                long price = (long)row["price"];
                long beds = roomCapacity((string)row["beds"]);
                if(price/beds < min)
                {
                    min = (double)price / (double)beds;
                    id = roomid;
                }
            }

            query = "SELECT * FROM Rooms WHERE roomID = " + id;
            DataSet best = fn.getData(query);
            DataTable bestT = best.Tables[0];
            DataRow bestrow = bestT.Rows[0];

            labelBestBuy.Text = "BEST BUY: soba " + bestrow["roomNo"] + " | Price per bed: " + (int)min + " | " + bestrow["roomType"] + " | " + bestrow["beds"];
        }
    }
}
