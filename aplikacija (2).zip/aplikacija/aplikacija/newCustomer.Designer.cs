﻿namespace aplikacija
{
    partial class newCustomer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtGender = new System.Windows.Forms.ComboBox();
            this.dateIN = new System.Windows.Forms.DateTimePicker();
            this.dateOUT = new System.Windows.Forms.DateTimePicker();
            this.txtRoomNo = new System.Windows.Forms.ComboBox();
            this.txtBed = new System.Windows.Forms.ComboBox();
            this.txtType = new System.Windows.Forms.ComboBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBoxGenderComp2 = new System.Windows.Forms.ComboBox();
            this.textBoxNameComp2 = new System.Windows.Forms.TextBox();
            this.labelgendercomp2 = new System.Windows.Forms.Label();
            this.labelnamecomp2 = new System.Windows.Forms.Label();
            this.comboBoxGenderComp1 = new System.Windows.Forms.ComboBox();
            this.textBoxNameComp1 = new System.Windows.Forms.TextBox();
            this.labelgendercomp1 = new System.Windows.Forms.Label();
            this.labelnamecomp1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNoGuests = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(401, 40);
            this.label1.TabIndex = 2;
            this.label1.Text = "Customer registration";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(48, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 28);
            this.label2.TabIndex = 3;
            this.label2.Text = "Name guest 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(48, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 28);
            this.label3.TabIndex = 4;
            this.label3.Text = "Gender guest 1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(48, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(171, 28);
            this.label6.TabIndex = 7;
            this.label6.Text = "Check in date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(389, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(188, 28);
            this.label7.TabIndex = 8;
            this.label7.Text = "Check out date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(729, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(176, 28);
            this.label8.TabIndex = 9;
            this.label8.Text = "Room number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(388, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 28);
            this.label9.TabIndex = 10;
            this.label9.Text = "Bed";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(389, 133);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(142, 28);
            this.label10.TabIndex = 11;
            this.label10.Text = "Room Type";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(727, 258);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 28);
            this.label11.TabIndex = 12;
            this.label11.Text = "Price";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MistyRose;
            this.button1.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(52, 407);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(934, 51);
            this.button1.TabIndex = 13;
            this.button1.Text = "Add reservation";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(52, 70);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(252, 22);
            this.txtName.TabIndex = 14;
            // 
            // txtGender
            // 
            this.txtGender.FormattingEnabled = true;
            this.txtGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.txtGender.Location = new System.Drawing.Point(53, 185);
            this.txtGender.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(252, 24);
            this.txtGender.TabIndex = 15;
            // 
            // dateIN
            // 
            this.dateIN.Location = new System.Drawing.Point(53, 315);
            this.dateIN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateIN.MinDate = new System.DateTime(2023, 1, 18, 0, 0, 0, 0);
            this.dateIN.Name = "dateIN";
            this.dateIN.Size = new System.Drawing.Size(252, 22);
            this.dateIN.TabIndex = 18;
            this.dateIN.ValueChanged += new System.EventHandler(this.dateIN_ValueChanged);
            // 
            // dateOUT
            // 
            this.dateOUT.Location = new System.Drawing.Point(394, 315);
            this.dateOUT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateOUT.Name = "dateOUT";
            this.dateOUT.Size = new System.Drawing.Size(252, 22);
            this.dateOUT.TabIndex = 19;
            // 
            // txtRoomNo
            // 
            this.txtRoomNo.FormattingEnabled = true;
            this.txtRoomNo.Location = new System.Drawing.Point(732, 185);
            this.txtRoomNo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRoomNo.Name = "txtRoomNo";
            this.txtRoomNo.Size = new System.Drawing.Size(252, 24);
            this.txtRoomNo.TabIndex = 20;
            this.txtRoomNo.SelectedIndexChanged += new System.EventHandler(this.txtRoomNo_SelectedIndexChanged);
            // 
            // txtBed
            // 
            this.txtBed.FormattingEnabled = true;
            this.txtBed.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Triple"});
            this.txtBed.Location = new System.Drawing.Point(393, 70);
            this.txtBed.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBed.Name = "txtBed";
            this.txtBed.Size = new System.Drawing.Size(252, 24);
            this.txtBed.TabIndex = 21;
            this.txtBed.SelectedIndexChanged += new System.EventHandler(this.txtBed_SelectedIndexChanged);
            // 
            // txtType
            // 
            this.txtType.FormattingEnabled = true;
            this.txtType.Items.AddRange(new object[] {
            "Classic",
            "Premium",
            "Apartman"});
            this.txtType.Location = new System.Drawing.Point(393, 187);
            this.txtType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(252, 24);
            this.txtType.TabIndex = 22;
            this.txtType.SelectedIndexChanged += new System.EventHandler(this.txtType_SelectedIndexChanged);
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(733, 313);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.ReadOnly = true;
            this.txtPrice.Size = new System.Drawing.Size(252, 22);
            this.txtPrice.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.comboBoxGenderComp2);
            this.panel1.Controls.Add(this.textBoxNameComp2);
            this.panel1.Controls.Add(this.labelgendercomp2);
            this.panel1.Controls.Add(this.labelnamecomp2);
            this.panel1.Controls.Add(this.comboBoxGenderComp1);
            this.panel1.Controls.Add(this.textBoxNameComp1);
            this.panel1.Controls.Add(this.labelgendercomp1);
            this.panel1.Controls.Add(this.labelnamecomp1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtNoGuests);
            this.panel1.Controls.Add(this.txtPrice);
            this.panel1.Controls.Add(this.txtType);
            this.panel1.Controls.Add(this.txtBed);
            this.panel1.Controls.Add(this.txtRoomNo);
            this.panel1.Controls.Add(this.dateOUT);
            this.panel1.Controls.Add(this.dateIN);
            this.panel1.Controls.Add(this.txtGender);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(18, 93);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1376, 492);
            this.panel1.TabIndex = 24;
            // 
            // comboBoxGenderComp2
            // 
            this.comboBoxGenderComp2.FormattingEnabled = true;
            this.comboBoxGenderComp2.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxGenderComp2.Location = new System.Drawing.Point(1075, 424);
            this.comboBoxGenderComp2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxGenderComp2.Name = "comboBoxGenderComp2";
            this.comboBoxGenderComp2.Size = new System.Drawing.Size(252, 24);
            this.comboBoxGenderComp2.TabIndex = 33;
            this.comboBoxGenderComp2.Visible = false;
            // 
            // textBoxNameComp2
            // 
            this.textBoxNameComp2.Location = new System.Drawing.Point(1074, 314);
            this.textBoxNameComp2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxNameComp2.Name = "textBoxNameComp2";
            this.textBoxNameComp2.Size = new System.Drawing.Size(252, 22);
            this.textBoxNameComp2.TabIndex = 32;
            this.textBoxNameComp2.Visible = false;
            // 
            // labelgendercomp2
            // 
            this.labelgendercomp2.AutoSize = true;
            this.labelgendercomp2.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelgendercomp2.Location = new System.Drawing.Point(1070, 372);
            this.labelgendercomp2.Name = "labelgendercomp2";
            this.labelgendercomp2.Size = new System.Drawing.Size(192, 28);
            this.labelgendercomp2.TabIndex = 31;
            this.labelgendercomp2.Text = "Gender guest 3";
            this.labelgendercomp2.Visible = false;
            // 
            // labelnamecomp2
            // 
            this.labelnamecomp2.AutoSize = true;
            this.labelnamecomp2.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnamecomp2.Location = new System.Drawing.Point(1070, 258);
            this.labelnamecomp2.Name = "labelnamecomp2";
            this.labelnamecomp2.Size = new System.Drawing.Size(174, 28);
            this.labelnamecomp2.TabIndex = 30;
            this.labelnamecomp2.Text = "Name guest 3";
            this.labelnamecomp2.Visible = false;
            // 
            // comboBoxGenderComp1
            // 
            this.comboBoxGenderComp1.FormattingEnabled = true;
            this.comboBoxGenderComp1.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxGenderComp1.Location = new System.Drawing.Point(1075, 185);
            this.comboBoxGenderComp1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxGenderComp1.Name = "comboBoxGenderComp1";
            this.comboBoxGenderComp1.Size = new System.Drawing.Size(252, 24);
            this.comboBoxGenderComp1.TabIndex = 29;
            this.comboBoxGenderComp1.Visible = false;
            // 
            // textBoxNameComp1
            // 
            this.textBoxNameComp1.Location = new System.Drawing.Point(1074, 70);
            this.textBoxNameComp1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxNameComp1.Name = "textBoxNameComp1";
            this.textBoxNameComp1.Size = new System.Drawing.Size(252, 22);
            this.textBoxNameComp1.TabIndex = 28;
            this.textBoxNameComp1.Visible = false;
            // 
            // labelgendercomp1
            // 
            this.labelgendercomp1.AutoSize = true;
            this.labelgendercomp1.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelgendercomp1.Location = new System.Drawing.Point(1070, 133);
            this.labelgendercomp1.Name = "labelgendercomp1";
            this.labelgendercomp1.Size = new System.Drawing.Size(192, 28);
            this.labelgendercomp1.TabIndex = 27;
            this.labelgendercomp1.Text = "Gender guest 2";
            this.labelgendercomp1.Visible = false;
            // 
            // labelnamecomp1
            // 
            this.labelnamecomp1.AutoSize = true;
            this.labelnamecomp1.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnamecomp1.Location = new System.Drawing.Point(1070, 14);
            this.labelnamecomp1.Name = "labelnamecomp1";
            this.labelnamecomp1.Size = new System.Drawing.Size(174, 28);
            this.labelnamecomp1.TabIndex = 26;
            this.labelnamecomp1.Text = "Name guest 2";
            this.labelnamecomp1.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(729, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(218, 28);
            this.label4.TabIndex = 25;
            this.label4.Text = "Number of guests";
            // 
            // txtNoGuests
            // 
            this.txtNoGuests.FormattingEnabled = true;
            this.txtNoGuests.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Triple"});
            this.txtNoGuests.Location = new System.Drawing.Point(734, 70);
            this.txtNoGuests.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNoGuests.Name = "txtNoGuests";
            this.txtNoGuests.Size = new System.Drawing.Size(252, 24);
            this.txtNoGuests.TabIndex = 24;
            this.txtNoGuests.SelectedIndexChanged += new System.EventHandler(this.txtNoGuests_SelectedIndexChanged);
            // 
            // newCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "newCustomer";
            this.Size = new System.Drawing.Size(1420, 611);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ComboBox txtGender;
        private System.Windows.Forms.DateTimePicker dateIN;
        private System.Windows.Forms.DateTimePicker dateOUT;
        private System.Windows.Forms.ComboBox txtRoomNo;
        private System.Windows.Forms.ComboBox txtBed;
        private System.Windows.Forms.ComboBox txtType;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox txtNoGuests;
        private System.Windows.Forms.ComboBox comboBoxGenderComp2;
        private System.Windows.Forms.TextBox textBoxNameComp2;
        private System.Windows.Forms.Label labelgendercomp2;
        private System.Windows.Forms.Label labelnamecomp2;
        private System.Windows.Forms.ComboBox comboBoxGenderComp1;
        private System.Windows.Forms.TextBox textBoxNameComp1;
        private System.Windows.Forms.Label labelgendercomp1;
        private System.Windows.Forms.Label labelnamecomp1;
    }
}
