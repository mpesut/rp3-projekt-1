﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    public partial class Invoices : UserControl
    {
        DBfunctions fn = new DBfunctions();
        string query;
        public Invoices()
        {
            InitializeComponent();
            query = "select * from reservations";
        }

        public void Invoices_Load(object sender, EventArgs e)
        {
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns[0].ReadOnly = true;
        }

        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row = dataGridView1.SelectedRows[0];
            DateTime time = DateTime.Now;
            long overall = (long)row.Cells["overall"].Value;
            int resID = (int)row.Cells["reservationID"].Value;

            MessageBox.Show("UKUPNI IZNOS: " + overall + "\n" + 
                "DATUM IZDAVANJA: " + time + "\n"
                 ,"RAČUN ZA REZERVACIJU BROJ: " + resID);
        }
    }
}
