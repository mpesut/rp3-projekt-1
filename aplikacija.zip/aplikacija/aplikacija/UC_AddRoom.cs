﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija.User_Control
{
    public partial class UC_AddRoom : UserControl
    {
        DBfunctions fn = new DBfunctions();
        string query;
        public event EventHandler<EventArgs> dodanaSoba;
        public UC_AddRoom()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        public void UC_AddRoom_Load(object sender, EventArgs e)
        {
            query = "select * from Rooms";
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns[0].ReadOnly = true;
        }

        private void btnAddRoom_Click(object sender, EventArgs e)
        {
            if(txtRoomNo.Text != "" && txtRoomNo.Text != "" && txtRoomType.Text != "" && txtBeds.Text != "")
            {
                string number = txtRoomNo.Text;
                string typeR = txtRoomType.Text;
                string beds = txtBeds.Text;
                Int64 price = Int64.Parse(txtPrice.Text);

                query = "insert into Rooms (roomNo, roomType, beds, price) values ('" + number + "','" + typeR + "','" + beds + "'," + price + ")";
                try
                {
                    fn.setData(query, "Room added!");
                }
                catch
                {
                    MessageBox.Show("Već postoji soba sa unesenim brojem. Unesite drugi broj.", "Greška");
                }

                UC_AddRoom_Load(this, null);
                dodanaSoba(this, null);
                ClearAll();
            }
            else
            {
                MessageBox.Show("Fill all the fields!", "Warning !!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ClearAll()
        {
            txtRoomNo.Clear();
            txtPrice.Clear();
            txtBeds.SelectedIndex = -1;
            txtRoomType.SelectedIndex = -1;
        }

        private void UC_AddRoom_Leave(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
