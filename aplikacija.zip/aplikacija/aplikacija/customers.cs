﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    public partial class customers : UserControl
    {
        DBfunctions fn = new DBfunctions();
        string query = "select guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID";
        public customers()
        {
            InitializeComponent();
        }

        public void customers_Load(object sender, EventArgs e)
        {
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns[0].ReadOnly = true;
        }

        private void button4_Click(object sender, EventArgs e) //All
        {
            query = "select guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID";
            customers_Load(this, null);
        }

        private void button3_Click(object sender, EventArgs e) // rezervacije
        {
            query = "select guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID and checkedOut is null and checkedIn is null";
            customers_Load(this, null);
        }

        private void button1_Click(object sender, EventArgs e) // checkedIn
        {
            query = "select guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID and checkedIn = 'YES'";
            customers_Load(this, null);
        }
    }
}
