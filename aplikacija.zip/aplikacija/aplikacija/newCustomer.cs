﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    public partial class newCustomer : UserControl
    {
        string query;
        DBfunctions fn = new DBfunctions();
        int rid;
        public event EventHandler<EventArgs> guestAdded;
        public newCustomer()
        {
            InitializeComponent();
            dateIN.MinDate = DateTime.Now;
            dateOUT.MinDate = DateTime.Now.AddDays(1);
        }

        private void txtRoomNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            query = "select price, roomID from Rooms where roomNo = '" + txtRoomNo.Text + "'";
            DataSet ds = fn.getData(query);
            txtPrice.Text = ds.Tables[0].Rows[0][0].ToString();
            rid = int.Parse(ds.Tables[0].Rows[0][1].ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "" && txtRoomNo.Text != "" && txtType.Text != "" && txtBed.Text != "" && 
                txtGender.Text != "" && dateIN.Text != "" && dateOUT.Text != "" &&
                txtPrice.Text != "")
            {
                string numberR = txtRoomNo.Text;
                string typeR = txtType.Text;
                string beds = txtBed.Text;
                string name = txtName.Text;
                string gender = txtGender.Text;
                string dateIn = dateIN.Text;
                string dateOut = dateOUT.Text;
                int numberG = (int)txtNoGuests.SelectedItem;
                Int64 price = Int64.Parse(txtPrice.Text);

                query = "insert into Guests (guestName, gender, dateIn, dateOut, roomID) values ('" + name + "','" + gender + "','" + dateIn + "','" + dateOut + "'," + rid  + ") update Rooms set booked = 'YES' where roomNo ='" + numberR + "'";
                fn.setData(query, "Guest added!");
                query = "select guestID from Guests where guestName = '" + name + "' and roomID = '" + rid + "'";
                DataSet guest = fn.getData(query);
                string guestid = guest.Tables[0].Rows[0][0].ToString();
                TimeSpan stay = dateOUT.Value - dateIN.Value;

                long overall = stay.Days * price;
                if (dateIN.Value.Date == DateTime.Now.Date)
                    overall += price;

                query = 
                    "insert into Reservations (guestID, guestName, roomID, roomType, dateIn, dateOut, price, overall) values" +
                    "(" + guestid + ",'" + name + "'," + rid + ",'" + typeR + "','" + dateIn + "','" + dateOut + "'," + price + "," + overall + ")";
                fn.setData(query, "Reservation created!");
                cleanPage();
                guestAdded(this, null);
            }
            else
            {
                MessageBox.Show("Fill all the fields!", "Information !!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void setCombo(string query, ComboBox combo)
        {
            SqlDataReader dr = fn.getCombo(query);
            while (dr.Read())
            {
                for(int i = 0; i < dr.FieldCount; i++)
                {
                    combo.Items.Add(dr.GetString(i));
                }
            }
            dr.Close();
        }

        private void txtType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtBed_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtRoomNo.Items.Clear();
            txtNoGuests.Items.Clear();
            txtRoomNo.Text = String.Empty;
            txtType.SelectedIndex = -1;
            txtPrice.Text = String.Empty;

            for (int i = 1; i <= capacity(txtBed.Text); i++)
                txtNoGuests.Items.Add(i);
        }

        private void cleanPage()
        {
            txtName.Clear();
            txtGender.SelectedIndex = -1;
            txtBed.SelectedIndex = -1;
            txtType.SelectedIndex = -1;
            txtNoGuests.Items.Clear();
            txtPrice.Text = String.Empty;
            txtRoomNo.Items.Clear();
        }

        private static int capacity(string beds)
        {
            switch(beds)
            {
                case "Single": return 1;
                case "Double": return 2;
                case "Triple": return 3;
            }
            return 0;
        }

        private void txtNoGuests_SelectedIndexChanged(object sender, EventArgs e)
        {
            int brojGostiju = (int)txtNoGuests.SelectedItem;
            string queryAvalaible = "select roomNo from Rooms where roomType ='" + txtType.Text + "' and beds = '" + txtBed.Text + "'";
            txtRoomNo.Items.Clear();
            txtPrice.Text = String.Empty;
            query = "select roomNo from Rooms where roomType ='" + txtType.Text + "' and beds = '" + txtBed.Text + "' and booked is null";
            setCombo(query, txtRoomNo);
        }
    }
}
